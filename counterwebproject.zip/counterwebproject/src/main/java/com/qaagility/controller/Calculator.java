package com.qaagility.controller;

public class Calculator {

  public int add() {
    return 3 + 6;
  
  }
  
  }
